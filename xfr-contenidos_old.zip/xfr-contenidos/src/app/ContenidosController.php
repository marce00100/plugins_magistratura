<?php
use frctl\MasterController;

class ContenidosController extends MasterController {
	// private $tabla = (object)[
	// 	'comunicados' => 'xfr_contenidos_magistratura',
	// 	'noticias'		=> 'xfr_contenidos_magistratura',
	// ];
	/**
	 * POST Obtiene los contenidos, $request tiene la informacion del datatable
	 * Exclusivo PARA DATATABLES desde servidor con  Ajax 
	 */
	public function getContentsPublic(WP_REST_Request $req) {
		/* Quitar si no es WP */
		$req = (object)$req->get_params();
		/* Parametros de DataTable */
		$obj = (object)[];
		$obj->draw            = $req->draw ?? 1;
		$obj->start           = $req->start ?? 1;
		$obj->length          = $req->length ?? 10;
		$obj->columnIndex     = $req->order[0]['column']; // Column index
		$obj->columnName      = $req->columns[$obj->columnIndex]['data']; // Column name
		$obj->columnSortOrder = $req->order[0]['dir']; // asc or desc
		$obj->searchValue     = html_entity_decode($req->search['value'], ENT_QUOTES | ENT_HTML5, 'UTF-8');

		$obj->estado_contenido = 1; /* Solo Activos */
		$obj->tipo_contenido   = $req->tipo_contenido ?? '';
		$obj->sub_tipo         = $req->sub_tipo ?? '';
		// return $obj;

		$obj->textoBusqueda = $req->texto_busqueda ?? null;

		$contenidos = $this->getContenidos($obj); 		

		return [
			'data'            => $contenidos->data,
			'draw'            => $contenidos->draw,
			"recordsTotal"    => $contenidos->recordsTotal,
			"recordsFiltered" => $contenidos->recordsFiltered,
			// 'query'						=> $contenidos->query,
		];
		
	}

	public function getContentsAdmin(WP_REST_Request $req) {

	}

	/**
	 * DE CLASE Obtiene los contenidos, $obj  tiene la informacion del datatable 
	 * Exclusivo PARA DATATABLES desde servidor con  Ajax 
	 */
	private function getContenidos($obj) {
		// mysqli_set_charset(wpdb, "utf8");
		$condicion = '';
		$condicion .= empty($obj->estado_contenido)  ? '' : " AND estado_contenido = {$obj->estado_contenido} ";
		$condicion .= empty($obj->tipo_contenido)   ? '' : " AND tipo_contenido like '{$obj->tipo_contenido}%' ";
		$condicion .= empty($obj->sub_tipo)         ? '' : " AND sub_tipo like '{$obj->sub_tipo}%' ";
		
		$condicionSearch =  $obj->searchValue ? " AND (titulo like '%{$obj->searchValue}%' OR resumen like '%{$obj->searchValue}%' OR texto like '%{$obj->searchValue}%' )" : "";
		
		/* Si es de busqueda gral*/
		$condicionSearch = $obj->textoBusqueda ?  " AND (titulo like '%{$obj->textoBusqueda}%' OR resumen like '%{$obj->textoBusqueda}%' OR texto like '%{$obj->textoBusqueda}%' )" : "";

		$sistema = $this->valorParametro((object)['dominio' => 'sistema', 'nombre' => 'sistema']);

		$DB = $this;
		$query = "SELECT id as id_contenido, tipo_contenido, sub_tipo, titulo, resumen, contenido, estado_contenido, imagen
						, fecha_publicacion, numero_vistas
						, SUBSTR(contenido, LOCATE('<img src=\"', contenido) + 10, LOCATE('\"', contenido, LOCATE('<img src=\"', contenido) + 10) - (LOCATE('<img src=\"', contenido) + 10)) AS url_primera_imagen
						-- , SUBSTRING(contenido, LOCATE('<img', contenido), LOCATE('>', contenido, LOCATE('<img', contenido)) - LOCATE('<img', contenido) + 1) AS primera_imagen
						, CASE WHEN (imagen IS NOT NULL AND imagen != '') THEN  CONCAT(SUBSTRING_INDEX(imagen, '.', 1), '_s.', SUBSTRING_INDEX(imagen, '.', -1)) 
						ELSE '' END AS imagen_sm
						FROM xfr_contenidos  WHERE TRUE {$condicion} {$condicionSearch}
						ORDER BY fecha_publicacion desc 
						LIMIT {$obj->start}, {$obj->length} 
						";
		$lista_contenidos = collect($DB->select($query));	

		$carpetaSeccion = '';

		if ($sistema == 'magistratura')
			$carpetaSeccion = 'noticias/';
		else if ($sistema == 'observatorio')
			$carpetaSeccion = $obj->tipo_contenido ? $obj->tipo_contenido . '/' : ''; 

		global $xfrContenidos;
		$pathSeccionImagen  = $xfrContenidos->pathImagenes . $carpetaSeccion;
		$urlSeccionImagen   = $xfrContenidos->urlImagenes . $carpetaSeccion;

		foreach ($lista_contenidos as $contenido) {
			if(!$contenido->resumen || trim($contenido->resumen) == ''){
				$contenidoSinTags = preg_replace('/<w[^>]*>[^>]*<\/w[^>]*>|<xml>[^>]*<\/xml>|<style>[^>]*<\/style>|<[^>]*>/', '', $contenido->contenido);
				// $contenidoSinTags = preg_replace('/\s|\n|\r|\t/', '', $contenidoSinTags);
				$contenido->resumen = substr(trim($contenidoSinTags), 0, 150);
			}

			/* si imagen_sm */
			if(!empty($contenido->imagen_sm) && file_exists($pathSeccionImagen . $contenido->imagen_sm)){
				$contenido->imagen_sm = $urlSeccionImagen . $contenido->imagen_sm;
				continue;
			}
			/* si imagen */
			else if(!empty($contenido->imagen) && file_exists($pathSeccionImagen . $contenido->imagen)){
				$contenido->imagen_sm = $urlSeccionImagen . $contenido->imagen;
				continue;
			}
			/* si primera_imagen */
			else if(!empty($contenido->url_primera_imagen) && file_exists($pathSeccionImagen . $contenido->url_primera_imagen)){
				$contenido->imagen_sm = $urlSeccionImagen . $contenido->url_primera_imagen;
				continue;
			}
			else{
				$contenido->path = $pathSeccionImagen . $contenido->url_primera_imagen;
				$contenido->url =$urlSeccionImagen . $contenido->url_primera_imagen;
				$contenido->imagen_sm = $xfrContenidos->urlImagenes . 'default_img.png';
			}

			// unset($contenido->contenido);
		}

		$recordsTotal = collect($DB->select("SELECT count(*) as total  FROM xfr_contenidos  WHERE TRUE {$condicion}  "))->first()->total;

		$recordsFiltered =  collect($DB->select("SELECT count(*) as total  FROM xfr_contenidos  WHERE TRUE {$condicion}  {$condicionSearch} "))->first()->total;

		return (object)[
			'data'            => $lista_contenidos->toArray(),
			'draw'            => $obj->draw,
			"recordsTotal"    => $recordsTotal,
			"recordsFiltered" => $recordsFiltered,
			"query" 					=> $query,
		];

	}

	/**
	 * POST obtener UN CONTENIDO 
	 */
	public function getContent(WP_REST_Request $req) {
		/* Quitar si no es WP */
		$req = (object)$req->get_params();
		$sistema = $this->valorParametro((object)['dominio' => 'sistema', 'nombre' => 'sistema']);

		$DB = $this;
		// replace(introtext, 'img src="images/', 'img src="../images/')
		$contenido = collect($DB->select("SELECT c.id as id_contenido, c.tipo_contenido, c.sub_tipo, 
										c.fecha_publicacion, c.titulo, c.resumen
										, c.contenido
										, c.imagen
										, c.estado_contenido, c.numero_vistas, c.extra_fields
										FROM xfr_contenidos c 
										WHERE c.id = {$req->id_contenido}"))->first();

		if(!$contenido)
			return ['status' => 'error', 'msg' => 'No existe el registro.'];

		$this->incrementaNumeroVistas($contenido->id_contenido);
		$contenido->numero_vistas ++;

		$carpetaSeccion = '';
		if ($sistema == 'magistratura') /* Si es de Magistratura solo se tiene la carpeta noticias */
			$carpetaSeccion = 'noticias/';
		else if ($sistema == 'observatorio')
			$carpetaSeccion = $contenido->tipo_contenido ? $contenido->tipo_contenido . '/' : ''; 
		
		global $xfrContenidos;
		$pathSeccionImagen  = $xfrContenidos->pathImagenes . $carpetaSeccion;
		$urlSeccionImagen   = $xfrContenidos->urlImagenes  . $carpetaSeccion;

		/** Acondicionamos algunos campos */
		
		/* si apunta a una imagen pero no existe */
		if(!empty($contenido->imagen) && !file_exists($pathSeccionImagen . $contenido->imagen))
			$contenido->imagen = null;

		/* Se verifica si existen las imagenes del contenido */
		// $dom = new DOMDocument();
		// $dom->loadHTML('<div>' . $contenido->contenido . '</div>');
		// /* Obtener todas las etiquetas <img> */
		// $imagenes = $dom->getElementsByTagName('img');
		// /* Recorrer todas las imágenes y obtener la URL de la imagen */
		// foreach ($imagenes as $imagen) {
		// 	$url = $imagen->getAttribute('src');
		// 	if (file_exists($pathSeccionImagen . $url)) {
		// 		$imagen->setAttribute('src', $urlSeccionImagen . $url );
		// 	}
		// 	else
		// 		$imagen->parentNode->removeChild($imagen);
		// }	

		// Obtener el HTML modificado
		// $contenido->contenido = $dom->textContent;//->saveHTML();
		// $contenido->contenido = html_entity_decode($contenido->contenido, ENT_QUOTES | ENT_HTML5, 'UTF-8');
		$contenido->contenido = str_replace('<img src="', '<img src="' . $urlSeccionImagen, $contenido->contenido);	

		$contenido->extra_fields = json_decode($contenido->extra_fields); 
		$contenido->sistema = $sistema;

		return (object)[
			'data'    => $contenido,
			'status' => 'ok'
		];
	}

	/**
	 * DE CLASE incrementa el numero de vistas en 1
	 */
	private function incrementaNumeroVistas($id_contenido){
		$this->statement("UPDATE xfr_contenidos set numero_vistas = numero_vistas + 1 WHERE id = {$id_contenido}");
	}


	
	/**
	 * POST PAra insertar o actualizar a un contenido
	 */
	public function saveContenido(WP_REST_Request $req) {
		$req = (object)$req->get_params();
		$req = (object)$req->data_save;
		
		// return ['data'=>$req];
		$obj                    = (object)[];
		$obj->id                = $req->id_contenido ?? null;
		$obj->titulo            = $req->titulo;
		$obj->texto             = $req->texto;
		$obj->tipo_contenido    = $req->tipo_contenido;
		$obj->imagen            = $req->imagen ?? null;
		$obj->estado_contenido  = $req->estado_contenido;
		$obj->prioridad         = $req->prioridad;
		$obj->fecha_publicacion = $req->fecha_publicacion;

		/** solo para insert */
		!($req->id_contenido) ? $obj->fecha_registro    = $this->now() : false;
		!($req->id_contenido) ? $obj->numero_visitas    = 1 : false;
		!($req->id_contenido) ? $obj->created_at        = $this->now() : false;
		!($req->id_contenido) ? $obj->created_by        = 1 : false;
		/** Solo para caso update */
		($req->id_contenido) ? $obj->updated_at    		= $req->updated_at : false;
		($req->id_contenido) ? $obj->updated_by    		= 1 : false;

		$obj->id_contenido = $this->guardarObjetoTabla($obj, 'xfr_contenidos');

		return [
			'data'   => $obj,
			'msg'    => "Se guardó correctamente",
			"status" => "ok"
		];
	}









}
