<?php
$contenidoPrefijRuta = "cont/v1/";

Route::post($contenidoPrefijRuta, 'get-contents'   , 'Contenidos@getContentsPublic');
Route::post($contenidoPrefijRuta, 'get-content'    , 'Contenidos@getContent');
Route::post($contenidoPrefijRuta, 'save-content'   , 'Contenidos@saveContent');


Route::post($contenidoPrefijRuta, 
  'migrate-tables-to-xfr-contenidos-format', 'ContenidosMigrate@migrarTablas');



