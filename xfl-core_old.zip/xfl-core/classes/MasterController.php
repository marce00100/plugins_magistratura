<?php
namespace frctl;

use WP_REST_Request;
use XFL_Core;

class MasterController {

	/***********************  FUNCIONES GENERALES *********************** */
	
	protected function params() {
		$dirWP = ABSPATH; /* el path del ditrrectorio donde esta wordpress */
		$urlWP = get_site_url(); /*La url   del itio wordpress */
		return (object)[
			'pathWP'         => $dirWP,
			'urlWP'          => $urlWP,
			'pathArchivos'	 => $dirWP . 'wp-content/archivos/',
			// 'urlArchivos'	 	 => $dirWP . 'wp-content/archivos/',
		];
	}

	/**
	 * Retorna la fecha y hora en zona horaria -4  BOLIVIA
	 */
	protected function now() {
		return date("Y-m-d H:i:s", time() - 4 * 60 * 60);
	}

/** ******** ****          FUNCIONES PARA CONSULTAS Y QUERYS PARA LA BD                ************************/

	/** FUNCIONES SQL para LARAVEL , si no se utilizan comentarlas -  No Borrar */
	// protected function select($query){
	//     return \DB::select($query);
	// } 

	// protected function statement($query){
	//     return \DB::statement($query);
	// }

	/** FUNCIONES SQL para WP , si no se utilizan comentarlas -  No Borrar */
	protected function select($query) {
		global $wpdb;
		$wpdb = isset($wpdb) ? $wpdb : (object)[];
		return $wpdb->get_results($query);
	}

	protected function statement($query) {
		global $wpdb;
		$wpdb = isset($wpdb) ? $wpdb : (object)[];
		return $wpdb->query($query);
	}


		/**
	 * Funcion Generica para incsertar o modificar las tablas
	 * (se usa cuando el id se autogenera en la BD, autonumerico, serial, trigger, etc)
	 */
	protected function guardarObjetoTabla($obj, $tabla, $datosAuditoria = false) {

		try {
			global $wpdb;
			if (isset($obj->id) && $obj->id !== '') // UPDATE 
			{
				// $obj->activo =  true;
				// if ($datosAuditoria) {
				// 	$obj->updated_by = $this->usuario->id ?? null;
				// 	$obj->updated_at = $this->now();
				// }
				$wpdb->update($tabla, get_object_vars($obj),  array('id' => $obj->id));
				// \DB::table($tabla)->where('id', $obj->id)->update(get_object_vars($obj));
				return $obj->id;
			} else // INSERT
			{
				unset($obj->id);
				// $obj->activo = true;
				// if ($datosAuditoria) {
				// 	$obj->created_by =  $this->usuario->id ?? null;
				// 	$obj->created_at =  $this->now();
				// }
				$wpdb->insert($tabla, get_object_vars($obj));
				return $wpdb->insert_id;
				// return \DB::table($tabla)->insertGetId(get_object_vars($obj));
			}
		} catch (Exception $e) {
			return response()->json(
				array(
					'status' => "error",
					'msg'    => $e->getMessage()
				)
			);
		}
	}

	/**
	 * CLASE Obtiene losparametros de un dominio {dominio:dominio}
	 */
	protected function parametrosDominio($obj){
		$DB = $this;
		$parametros = $DB->select("SELECT * FROM xfr_parametros WHERE dominio = '{$obj->dominio}' and activo = 1 
																ORDER by orden, nombre");
		return $parametros;
	}

	/**
	 * CLASE obtiene el valor de un parametro obj = (object)[dominio=>dominio, nombre=>nombre]
	 */
	protected function valorParametro($obj){
		$DB = $this;
		$param = collect($DB->select("SELECT * FROM xfr_parametros 
																	WHERE dominio = '{$obj->dominio}' AND nombre = '{$obj->nombre}' AND activo = 1 "))->first();
		return $param ? $param->valor : null;
	}

	/** *********************************    FIN FUNCIONES DB   ********************************************** */
	
	/** *********************************   FUNCIONES API GENERALES ***************************************** */
	/**
	 * POST : Obtiene losparametros de un dominio
	 * request  {dominio:dominio}
	 */
	public function getParametrosDominio(WP_REST_Request $req) {
		$req = (object)$req->get_params();
		return [
			'data' => $this->parametrosDominio((object)['dominio' => $req->dominio]),
			'status' => 'ok'
		];
	}



	/**
	 * POST Recupera un valor especifico de un parametro,si no encuentra el valor devuelve null y error
	 * request {dominio:dominio, nombre:nombre}
	 */
	public function getValorParametro(WP_REST_Request $req){
		$req = (object)$req->get_params();
		$dominio = $req->dominio;
		$nombre = $req->nombre;
		$valor = $this->valorParametro((object)[
																			'dominio' => $dominio,
																			'nombre' => $nombre
																		]);
		if(!$valor){
			return [
				'data' => null,
				'status' => 'error',
				'msg' => 'no existe el valor'
			];
		}
		
		return (object)[
			'data' => $valor->valor,
			'status' =>'ok'
		];
	}

	/** *******************************  FIN  FUNCIONES API GENERALES ***************************************** */


	
}
