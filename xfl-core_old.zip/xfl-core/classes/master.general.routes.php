<?php
$masterPrefijRuta = "gral/v1/";

Route::post($masterPrefijRuta, 'get-parametrosdominio', 'frctl\Master@getParametrosDominio');
Route::post($masterPrefijRuta, 'get-valorparametro'   , 'frctl\Master@getValorParametro');

